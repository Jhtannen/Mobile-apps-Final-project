
public class college {

        public String state;
        public String city;
        public int satAvg;
        public String schoolName;
        public String schoolUrl;

        public college(String state,String city,int satAvg,String schoolName,String schoolUrl) {
            // ...
        }

    }


